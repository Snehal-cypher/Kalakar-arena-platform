import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { DashboardContent } from "@/components/dashboard/dashboard-content";
import { Navbar } from "@/components/navbar";

export default async function DashboardPage() {
  const supabase = await createClient();
  
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    redirect("/auth/login");
  }

  if (user.user_metadata?.user_type !== "creator") {
    redirect("/explore");
  }

  // Get creator profile
  const { data: creatorProfile } = await supabase
    .from("creator_profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  // Get posts
  const { data: posts } = await supabase
    .from("posts")
    .select("*")
    .eq("creator_id", user.id)
    .order("created_at", { ascending: false });

  // Get follower count
  const { count: followerCount } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("following_id", user.id);

  // Get contact requests
  const { data: contactRequests } = await supabase
    .from("contact_requests")
    .select("*, profiles:user_id(full_name, avatar_url)")
    .eq("creator_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20">
        <DashboardContent
          user={user}
          creatorProfile={creatorProfile}
          posts={posts || []}
          followerCount={followerCount || 0}
          contactRequests={contactRequests || []}
        />
      </div>
    </main>
  );
}
