import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Navbar } from "@/components/navbar";
import { CreatorProfile } from "@/components/creator/creator-profile";

export default async function CreatorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  // Get current user
  const { data: { user } } = await supabase.auth.getUser();

  // Get creator profile with profile info
  const { data: creator, error } = await supabase
    .from("creator_profiles")
    .select(`
      *,
      profiles:id(full_name, email)
    `)
    .eq("id", id)
    .single();

  if (error || !creator) {
    notFound();
  }

  // Get posts
  const { data: posts } = await supabase
    .from("posts")
    .select("*")
    .eq("creator_id", id)
    .order("created_at", { ascending: false });

  // Get follower count
  const { count: followerCount } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("following_id", id);

  // Check if current user follows this creator
  let isFollowing = false;
  if (user) {
    const { data: follow } = await supabase
      .from("follows")
      .select("id")
      .eq("follower_id", user.id)
      .eq("following_id", id)
      .single();
    isFollowing = !!follow;
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20">
        <CreatorProfile
          creator={creator}
          posts={posts || []}
          followerCount={followerCount || 0}
          isFollowing={isFollowing}
          currentUserId={user?.id}
        />
      </div>
    </main>
  );
}
