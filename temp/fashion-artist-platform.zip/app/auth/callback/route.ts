import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/";

  if (code) {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.exchangeCodeForSession(code);
    
    if (!error && data.user) {
      const userType = data.user.user_metadata?.user_type;
      const redirectUrl = userType === "creator" ? "/dashboard" : "/explore";
      return NextResponse.redirect(`${origin}${redirectUrl}`);
    }
  }

  return NextResponse.redirect(`${origin}/auth/error`);
}
