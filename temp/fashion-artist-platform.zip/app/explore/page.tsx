import { Suspense } from "react";
import { createClient } from "@/lib/supabase/server";
import { Navbar } from "@/components/navbar";
import { ExploreContent } from "@/components/explore/explore-content";
import { Loader2 } from "lucide-react";

interface SearchParams {
  category?: string;
  search?: string;
}

export default async function ExplorePage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const supabase = await createClient();

  // Get current user
  const { data: { user } } = await supabase.auth.getUser();

  // Build query for profiles that are creators, with their posts
  let query = supabase
    .from("profiles")
    .select(`
      *,
      creator_profiles!creator_profiles_user_id_fkey(*),
      posts!posts_creator_id_fkey(id, title, image_url, category, created_at)
    `)
    .eq("user_type", "creator")
    .order("created_at", { ascending: false });

  const { data: creators } = await query;

  // Filter by search term and category if provided
  let filteredCreators = creators || [];
  
  if (params.category) {
    filteredCreators = filteredCreators.filter((creator) => {
      const specialty = creator.creator_profiles?.specialty || [];
      return specialty.some((s: string) => s.toLowerCase() === params.category?.toLowerCase());
    });
  }
  
  if (params.search) {
    const searchLower = params.search.toLowerCase();
    filteredCreators = filteredCreators.filter((creator) => {
      const name = creator.full_name?.toLowerCase() || "";
      const bio = creator.bio?.toLowerCase() || "";
      const specialty = creator.creator_profiles?.specialty?.join(" ").toLowerCase() || "";
      return (
        name.includes(searchLower) ||
        bio.includes(searchLower) ||
        specialty.includes(searchLower)
      );
    });
  }

  // Get user's follows if logged in
  let followedIds: string[] = [];
  if (user) {
    const { data: follows } = await supabase
      .from("follows")
      .select("following_id")
      .eq("follower_id", user.id);
    followedIds = follows?.map((f) => f.following_id) || [];
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20">
        <Suspense
          fallback={
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          }
        >
          <ExploreContent
            creators={filteredCreators}
            currentUserId={user?.id}
            followedIds={followedIds}
            currentCategory={params.category}
            currentSearch={params.search}
          />
        </Suspense>
      </div>
    </main>
  );
}
