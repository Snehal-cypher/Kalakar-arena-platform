import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { MessagesContent } from "@/components/messages/messages-content";

export const metadata = {
  title: "Messages | KALAKAR ARENA",
  description: "Chat with creators and manage your conversations",
};

export default async function MessagesPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login?redirect=/messages");
  }

  // Get user profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1 pt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-5xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-serif font-bold text-foreground">
                Messages
              </h1>
              <p className="text-muted-foreground mt-2">
                Chat with creators and manage your conversations
              </p>
            </div>

            <MessagesContent
              currentUserId={user.id}
              userType={profile?.user_type || "user"}
            />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
