import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Navbar } from "@/components/navbar";
import { UserProfile } from "@/components/profile/user-profile";

export default async function ProfilePage() {
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login");
  }

  // If user is a creator, redirect to dashboard
  if (user.user_metadata?.user_type === "creator") {
    redirect("/dashboard");
  }

  // Get user profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  // Get followed creators with their profiles
  const { data: follows } = await supabase
    .from("follows")
    .select(`
      id,
      following_id,
      created_at,
      creator_profiles:following_id(
        id,
        bio,
        avatar_url,
        city,
        categories,
        profiles:id(full_name)
      )
    `)
    .eq("follower_id", user.id);

  // Get contact requests sent by user
  const { data: contactRequests } = await supabase
    .from("contact_requests")
    .select(`
      *,
      creator_profiles:creator_id(
        id,
        avatar_url,
        profiles:id(full_name)
      )
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20">
        <UserProfile
          user={user}
          profile={profile}
          follows={follows || []}
          contactRequests={contactRequests || []}
        />
      </div>
    </main>
  );
}
