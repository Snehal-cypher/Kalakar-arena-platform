import { Navbar } from "@/components/navbar";
import { HeroSection } from "@/components/landing/hero-section";
import { AboutSection } from "@/components/landing/about-section";
import { RoadmapSection } from "@/components/landing/roadmap-section";
import { CTASection } from "@/components/landing/cta-section";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <RoadmapSection />
      <CTASection />
      <Footer />
    </main>
  );
}
