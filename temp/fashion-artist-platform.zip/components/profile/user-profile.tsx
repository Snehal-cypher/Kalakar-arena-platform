"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { User } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Heart,
  MessageSquare,
  LogOut,
  Loader2,
  MapPin,
  User as UserIcon,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";

interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
}

interface Follow {
  id: string;
  following_id: string;
  created_at: string;
  creator_profiles: {
    id: string;
    bio: string | null;
    avatar_url: string | null;
    city: string | null;
    categories: string[] | null;
    profiles: {
      full_name: string;
    };
  };
}

interface ContactRequest {
  id: string;
  message: string;
  status: string;
  created_at: string;
  creator_profiles: {
    id: string;
    avatar_url: string | null;
    profiles: {
      full_name: string;
    };
  };
}

interface UserProfileProps {
  user: User;
  profile: Profile | null;
  follows: Follow[];
  contactRequests: ContactRequest[];
}

export function UserProfile({ user, profile, follows, contactRequests }: UserProfileProps) {
  const [loggingOut, setLoggingOut] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const handleLogout = async () => {
    setLoggingOut(true);
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case "accepted":
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "rejected":
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "accepted":
        return "bg-green-100 text-green-700";
      case "rejected":
        return "bg-red-100 text-red-700";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <Card className="border-border mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
              {profile?.avatar_url ? (
                <img
                  src={profile.avatar_url || "/placeholder.svg"}
                  alt={profile.full_name || "User"}
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <UserIcon className="w-12 h-12 text-primary" />
              )}
            </div>
            <div className="flex-1 text-center sm:text-left">
              <h1 className="font-serif text-2xl font-bold text-foreground">
                {user.user_metadata?.full_name || profile?.full_name || "User"}
              </h1>
              <p className="text-muted-foreground">{user.email}</p>
              <div className="flex items-center justify-center sm:justify-start gap-4 mt-4">
                <div className="text-center">
                  <div className="font-bold text-foreground">{follows.length}</div>
                  <div className="text-xs text-muted-foreground">Following</div>
                </div>
                <div className="text-center">
                  <div className="font-bold text-foreground">{contactRequests.length}</div>
                  <div className="text-xs text-muted-foreground">Inquiries</div>
                </div>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={handleLogout}
              disabled={loggingOut}
              className="border-destructive text-destructive hover:bg-destructive/10 bg-transparent"
            >
              {loggingOut ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="following" className="space-y-6">
        <TabsList className="bg-muted">
          <TabsTrigger
            value="following"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Heart className="w-4 h-4 mr-2" />
            Following ({follows.length})
          </TabsTrigger>
          <TabsTrigger
            value="inquiries"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            My Inquiries ({contactRequests.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="following">
          {follows.length === 0 ? (
            <Card className="border-border border-dashed">
              <CardContent className="py-12 text-center">
                <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h4 className="font-medium text-foreground mb-2">No creators followed yet</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  Start exploring and follow creators whose work you love
                </p>
                <Link href="/explore">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Explore Creators
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {follows.map((follow) => (
                <Link key={follow.id} href={`/creator/${follow.following_id}`}>
                  <Card className="border-border hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-full bg-primary/10 flex-shrink-0 overflow-hidden">
                          {follow.creator_profiles?.avatar_url ? (
                            <img
                              src={follow.creator_profiles.avatar_url || "/placeholder.svg"}
                              alt={follow.creator_profiles.profiles?.full_name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <span className="text-primary font-semibold text-xl">
                                {follow.creator_profiles?.profiles?.full_name?.charAt(0) || "C"}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-foreground truncate">
                            {follow.creator_profiles?.profiles?.full_name || "Creator"}
                          </h4>
                          {follow.creator_profiles?.city && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <MapPin className="w-3 h-3" />
                              {follow.creator_profiles.city}
                            </div>
                          )}
                          {follow.creator_profiles?.categories && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {follow.creator_profiles.categories.slice(0, 2).map((cat) => (
                                <span
                                  key={cat}
                                  className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary"
                                >
                                  {cat}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="inquiries">
          {contactRequests.length === 0 ? (
            <Card className="border-border border-dashed">
              <CardContent className="py-12 text-center">
                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h4 className="font-medium text-foreground mb-2">No inquiries sent yet</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  Contact creators to discuss your requirements
                </p>
                <Link href="/explore">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Find Creators
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {contactRequests.map((request) => (
                <Card key={request.id} className="border-border">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Link href={`/creator/${request.creator_profiles?.id}`}>
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex-shrink-0 overflow-hidden">
                          {request.creator_profiles?.avatar_url ? (
                            <img
                              src={request.creator_profiles.avatar_url || "/placeholder.svg"}
                              alt={request.creator_profiles.profiles?.full_name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <span className="text-primary font-semibold">
                                {request.creator_profiles?.profiles?.full_name?.charAt(0) || "C"}
                              </span>
                            </div>
                          )}
                        </div>
                      </Link>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Link
                            href={`/creator/${request.creator_profiles?.id}`}
                            className="font-medium text-foreground hover:text-primary"
                          >
                            {request.creator_profiles?.profiles?.full_name || "Creator"}
                          </Link>
                          <span
                            className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${getStatusStyles(
                              request.status
                            )}`}
                          >
                            {getStatusIcon(request.status)}
                            {request.status}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {new Date(request.created_at).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </p>
                        <p className="text-foreground bg-muted rounded-lg p-3 text-sm">
                          {request.message}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
