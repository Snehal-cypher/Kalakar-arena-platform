import Link from "next/link";
import { Palette } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <Palette className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-serif text-xl font-bold">KALAKAR ARENA</span>
            </Link>
            <p className="text-background/70 text-sm leading-relaxed">
              Connecting talented local creators with people seeking unique, 
              handcrafted products and services.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-background/70">
              <li><Link href="/explore" className="hover:text-background transition-colors">Explore Creators</Link></li>
              <li><Link href="/categories" className="hover:text-background transition-colors">Categories</Link></li>
              <li><Link href="/about" className="hover:text-background transition-colors">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-background transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* For Creators */}
          <div>
            <h4 className="font-semibold mb-4">For Creators</h4>
            <ul className="space-y-2 text-background/70">
              <li><Link href="/auth/sign-up?type=creator" className="hover:text-background transition-colors">Join as Creator</Link></li>
              <li><Link href="/dashboard" className="hover:text-background transition-colors">Creator Dashboard</Link></li>
              <li><Link href="/guidelines" className="hover:text-background transition-colors">Community Guidelines</Link></li>
              <li><Link href="/faq" className="hover:text-background transition-colors">FAQ</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-semibold mb-4">Popular Categories</h4>
            <ul className="space-y-2 text-background/70">
              <li><Link href="/explore?category=fashion" className="hover:text-background transition-colors">Fashion Design</Link></li>
              <li><Link href="/explore?category=baking" className="hover:text-background transition-colors">Home Baking</Link></li>
              <li><Link href="/explore?category=jewelry" className="hover:text-background transition-colors">Jewelry Making</Link></li>
              <li><Link href="/explore?category=embroidery" className="hover:text-background transition-colors">Embroidery</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-background/20 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-background/60 text-sm">
            2024 KALAKAR ARENA. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-background/60 text-sm">
            <Link href="/privacy" className="hover:text-background transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-background transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
