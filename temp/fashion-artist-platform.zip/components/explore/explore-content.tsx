"use client";

import React from "react"

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CreatorCard } from "./creator-card";
import { Search, Filter, X } from "lucide-react";

const CATEGORIES = [
  "Fashion Design",
  "Home Baking",
  "Jewelry Making",
  "Embroidery",
  "Candle Making",
  "Pottery",
  "Crochet & Knitting",
  "Mehendi Art",
  "Custom Cakes",
  "Handmade Crafts",
  "Photography",
  "Painting",
  "Calligraphy",
];

interface Creator {
  id: string;
  full_name: string | null;
  email: string | null;
  bio: string | null;
  avatar_url: string | null;
  phone: string | null;
  city: string | null;
  creator_profiles: {
    specialty: string[] | null;
    portfolio_description: string | null;
    instagram: string | null;
    website: string | null;
  } | null;
  posts: {
    id: string;
    title: string;
    image_url: string;
    category: string | null;
    created_at: string;
  }[];
}

interface ExploreContentProps {
  creators: Creator[];
  currentUserId?: string;
  followedIds: string[];
  currentCategory?: string;
  currentSearch?: string;
}

export function ExploreContent({
  creators,
  currentUserId,
  followedIds,
  currentCategory,
  currentSearch,
}: ExploreContentProps) {
  const [searchQuery, setSearchQuery] = useState(currentSearch || "");
  const [showFilters, setShowFilters] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams(searchParams.toString());
    if (searchQuery) {
      params.set("search", searchQuery);
    } else {
      params.delete("search");
    }
    router.push(`/explore?${params.toString()}`);
  };

  const handleCategoryClick = (category: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (currentCategory === category) {
      params.delete("category");
    } else {
      params.set("category", category);
    }
    router.push(`/explore?${params.toString()}`);
  };

  const clearFilters = () => {
    setSearchQuery("");
    router.push("/explore");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground">
          Explore Creators
        </h1>
        <p className="text-muted-foreground mt-2">
          Discover talented local artists and their unique creations
        </p>
      </div>

      {/* Search and Filter */}
      <div className="mb-8 space-y-4">
        <div className="flex gap-3">
          <form onSubmit={handleSearch} className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search by name, skill, or keyword..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-input"
              />
            </div>
            <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Search
            </Button>
          </form>
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className={`border-border ${showFilters ? "bg-primary/10" : ""}`}
          >
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>

        {/* Category Filters */}
        {showFilters && (
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-foreground">Categories</h3>
              {(currentCategory || currentSearch) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4 mr-1" />
                  Clear all
                </Button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((category) => (
                <button
                  key={category}
                  onClick={() => handleCategoryClick(category)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                    currentCategory === category
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-primary/10 hover:text-primary"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Active Filters */}
        {(currentCategory || currentSearch) && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            {currentCategory && (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
                {currentCategory}
                <button onClick={() => handleCategoryClick(currentCategory)}>
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {currentSearch && (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
                Search: {currentSearch}
                <button onClick={() => {
                  setSearchQuery("");
                  const params = new URLSearchParams(searchParams.toString());
                  params.delete("search");
                  router.push(`/explore?${params.toString()}`);
                }}>
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
        )}
      </div>

      {/* Results */}
      {creators.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="font-serif text-xl font-semibold text-foreground mb-2">
            No creators found
          </h3>
          <p className="text-muted-foreground mb-4">
            Try adjusting your search or filters to find what you are looking for
          </p>
          <Button onClick={clearFilters} variant="outline" className="border-primary text-primary bg-transparent">
            Clear all filters
          </Button>
        </div>
      ) : (
        <>
          <p className="text-sm text-muted-foreground mb-4">
            Found {creators.length} creator{creators.length !== 1 ? "s" : ""}
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {creators.map((creator) => (
              <CreatorCard
                key={creator.id}
                creator={creator}
                isFollowing={followedIds.includes(creator.id)}
                currentUserId={currentUserId}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
