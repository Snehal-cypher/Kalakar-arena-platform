"use client";

import React from "react"

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, ImageIcon, Heart, Loader2 } from "lucide-react";

interface Creator {
  id: string;
  full_name: string | null;
  email: string | null;
  bio: string | null;
  avatar_url: string | null;
  phone: string | null;
  city: string | null;
  creator_profiles: {
    specialty: string[] | null;
    portfolio_description: string | null;
    instagram: string | null;
    website: string | null;
  } | null;
  posts: {
    id: string;
    title: string;
    image_url: string;
    category: string | null;
    created_at: string;
  }[];
}

interface CreatorCardProps {
  creator: Creator;
  isFollowing: boolean;
  currentUserId?: string;
}

export function CreatorCard({ creator, isFollowing, currentUserId }: CreatorCardProps) {
  const [following, setFollowing] = useState(isFollowing);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const handleFollow = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!currentUserId) {
      router.push("/auth/login");
      return;
    }

    setLoading(true);

    if (following) {
      await supabase
        .from("follows")
        .delete()
        .eq("follower_id", currentUserId)
        .eq("following_id", creator.id);
      setFollowing(false);
    } else {
      await supabase
        .from("follows")
        .insert({ follower_id: currentUserId, following_id: creator.id });
      setFollowing(true);
    }

    setLoading(false);
  };

  const latestPosts = creator.posts?.slice(0, 3) || [];

  return (
    <Link href={`/creator/${creator.id}`}>
      <Card className="border-border overflow-hidden hover:shadow-lg transition-shadow group cursor-pointer">
        {/* Posts Preview */}
        <div className="grid grid-cols-3 gap-0.5 aspect-video bg-muted">
          {latestPosts.length > 0 ? (
            latestPosts.map((post, index) => (
              <div
                key={post.id}
                className={`relative overflow-hidden ${
                  index === 0 && latestPosts.length === 1 ? "col-span-3" : ""
                } ${index === 0 && latestPosts.length === 2 ? "col-span-2 row-span-2" : ""}`}
              >
                <img
                  src={post.image_url || "/placeholder.svg"}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))
          ) : (
            <div className="col-span-3 flex items-center justify-center">
              <ImageIcon className="w-12 h-12 text-muted-foreground" />
            </div>
          )}
        </div>

        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {/* Avatar */}
            <div className="w-12 h-12 rounded-full bg-primary/10 flex-shrink-0 overflow-hidden">
              {creator.avatar_url ? (
                <img
                  src={creator.avatar_url || "/placeholder.svg"}
                  alt={creator.full_name || "Creator"}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-primary font-semibold text-lg">
                    {creator.full_name?.charAt(0) || "C"}
                  </span>
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-foreground truncate">
                  {creator.full_name || "Creator"}
                </h3>
                <Button
                  size="sm"
                  variant={following ? "default" : "outline"}
                  onClick={handleFollow}
                  disabled={loading}
                  className={following 
                    ? "bg-primary hover:bg-primary/90 text-primary-foreground" 
                    : "border-primary text-primary hover:bg-primary/10"
                  }
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Heart className={`w-4 h-4 mr-1 ${following ? "fill-current" : ""}`} />
                      {following ? "Following" : "Follow"}
                    </>
                  )}
                </Button>
              </div>

              {creator.city && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                  <MapPin className="w-3 h-3" />
                  {creator.city}
                </div>
              )}

              {creator.bio && (
                <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                  {creator.bio}
                </p>
              )}

              {/* Specialty */}
              {creator.creator_profiles?.specialty && creator.creator_profiles.specialty.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  {creator.creator_profiles.specialty.slice(0, 3).map((cat) => (
                    <span
                      key={cat}
                      className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary"
                    >
                      {cat}
                    </span>
                  ))}
                  {creator.creator_profiles.specialty.length > 3 && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                      +{creator.creator_profiles.specialty.length - 3}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
