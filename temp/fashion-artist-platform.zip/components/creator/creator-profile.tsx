"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  MapPin,
  Phone,
  Mail,
  Users,
  ImageIcon,
  Heart,
  MessageSquare,
  Loader2,
  Send,
  CheckCircle,
  MessageCircle,
} from "lucide-react";
import { StartChatButton } from "@/components/chat/start-chat-button";
import { LikeButton } from "@/components/posts/like-button";

interface Creator {
  id: string;
  bio: string | null;
  avatar_url: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  categories: string[] | null;
  profiles: {
    full_name: string;
    email: string;
  };
}

interface Post {
  id: string;
  title: string;
  description: string | null;
  image_url: string;
  category: string | null;
  created_at: string;
}

interface CreatorProfileProps {
  creator: Creator;
  posts: Post[];
  followerCount: number;
  isFollowing: boolean;
  currentUserId?: string;
}

export function CreatorProfile({
  creator,
  posts,
  followerCount,
  isFollowing: initialFollowing,
  currentUserId,
}: CreatorProfileProps) {
  const [following, setFollowing] = useState(initialFollowing);
  const [followLoading, setFollowLoading] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [sendingMessage, setSendingMessage] = useState(false);
  const [messageSent, setMessageSent] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const router = useRouter();
  const supabase = createClient();

  const handleFollow = async () => {
    if (!currentUserId) {
      router.push("/auth/login");
      return;
    }

    setFollowLoading(true);

    if (following) {
      await supabase
        .from("follows")
        .delete()
        .eq("follower_id", currentUserId)
        .eq("following_id", creator.id);
      setFollowing(false);
    } else {
      await supabase
        .from("follows")
        .insert({ follower_id: currentUserId, following_id: creator.id });
      setFollowing(true);
    }

    setFollowLoading(false);
    router.refresh();
  };

  const handleSendMessage = async () => {
    if (!currentUserId) {
      router.push("/auth/login");
      return;
    }

    if (!message.trim()) return;

    setSendingMessage(true);

    const { error } = await supabase.from("contact_requests").insert({
      user_id: currentUserId,
      creator_id: creator.id,
      message: message.trim(),
    });

    setSendingMessage(false);

    if (error) {
      console.error("Error sending message:", error);
      return;
    }

    setMessageSent(true);
    setMessage("");
    setTimeout(() => {
      setContactOpen(false);
      setMessageSent(false);
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <div className="bg-card border border-border rounded-2xl p-6 md:p-8 mb-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Avatar */}
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-primary/10 flex-shrink-0 overflow-hidden mx-auto md:mx-0">
            {creator.avatar_url ? (
              <img
                src={creator.avatar_url || "/placeholder.svg"}
                alt={creator.profiles?.full_name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-primary font-bold text-5xl">
                  {creator.profiles?.full_name?.charAt(0) || "C"}
                </span>
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 text-center md:text-left">
            <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground">
              {creator.profiles?.full_name || "Creator"}
            </h1>

            {/* Stats */}
            <div className="flex items-center justify-center md:justify-start gap-6 mt-4">
              <div className="text-center">
                <div className="text-xl font-bold text-foreground">{posts.length}</div>
                <div className="text-sm text-muted-foreground">Posts</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-foreground">{followerCount}</div>
                <div className="text-sm text-muted-foreground">Followers</div>
              </div>
            </div>

            {creator.bio && (
              <p className="text-muted-foreground mt-4 max-w-2xl">{creator.bio}</p>
            )}

            {/* Categories */}
            {creator.categories && creator.categories.length > 0 && (
              <div className="flex flex-wrap justify-center md:justify-start gap-2 mt-4">
                {creator.categories.map((cat) => (
                  <span
                    key={cat}
                    className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm"
                  >
                    {cat}
                  </span>
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-center md:justify-start gap-3 mt-6">
              <Button
                onClick={handleFollow}
                disabled={followLoading}
                className={
                  following
                    ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                    : "bg-transparent border-primary text-primary hover:bg-primary/10"
                }
                variant={following ? "default" : "outline"}
              >
                {followLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Heart className={`w-4 h-4 mr-2 ${following ? "fill-current" : ""}`} />
                    {following ? "Following" : "Follow"}
                  </>
                )}
              </Button>

              <StartChatButton
                creatorId={creator.id}
                creatorName={creator.profiles?.full_name || "Creator"}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              />

              <Dialog open={contactOpen} onOpenChange={setContactOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary/10 bg-transparent">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Inquiry
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="font-serif">
                      Contact {creator.profiles?.full_name}
                    </DialogTitle>
                    <DialogDescription>
                      Send a message to inquire about their services or discuss your requirements
                    </DialogDescription>
                  </DialogHeader>
                  {messageSent ? (
                    <div className="py-8 text-center">
                      <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                      <p className="font-medium text-foreground">Message Sent!</p>
                      <p className="text-sm text-muted-foreground">
                        The creator will get back to you soon
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Textarea
                        placeholder="Hi! I am interested in your work..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        rows={4}
                      />
                      <Button
                        onClick={handleSendMessage}
                        disabled={sendingMessage || !message.trim()}
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                      >
                        {sendingMessage ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send className="w-4 h-4 mr-2" />
                            Send Message
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Contact Info */}
          <div className="md:w-64 space-y-3 mt-4 md:mt-0">
            <h3 className="font-medium text-foreground text-center md:text-left">Contact Info</h3>
            {creator.profiles?.email && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground justify-center md:justify-start">
                <Mail className="w-4 h-4" />
                <span className="truncate">{creator.profiles.email}</span>
              </div>
            )}
            {creator.phone && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground justify-center md:justify-start">
                <Phone className="w-4 h-4" />
                {creator.phone}
              </div>
            )}
            {creator.city && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground justify-center md:justify-start">
                <MapPin className="w-4 h-4" />
                {creator.city}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Posts Grid */}
      <div>
        <div className="flex items-center gap-2 mb-6">
          <ImageIcon className="w-5 h-5 text-primary" />
          <h2 className="font-serif text-xl font-semibold text-foreground">Work Portfolio</h2>
        </div>

        {posts.length === 0 ? (
          <Card className="border-border border-dashed">
            <CardContent className="py-12 text-center">
              <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No posts yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {posts.map((post) => (
              <Card
                key={post.id}
                className="border-border overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => setSelectedPost(post)}
              >
                <div className="aspect-square relative bg-muted">
                  <img
                    src={post.image_url || "/placeholder.svg"}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground truncate">{post.title}</h4>
                      {post.category && (
                        <span className="inline-block mt-1 text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                          {post.category}
                        </span>
                      )}
                    </div>
                    <LikeButton postId={post.id} size="sm" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Post Modal */}
      <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
        <DialogContent className="sm:max-w-2xl">
          {selectedPost && (
            <>
              <div className="aspect-video relative bg-muted rounded-lg overflow-hidden">
                <img
                  src={selectedPost.image_url || "/placeholder.svg"}
                  alt={selectedPost.title}
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-serif text-xl font-semibold text-foreground">
                      {selectedPost.title}
                    </h3>
                    {selectedPost.category && (
                      <span className="inline-block mt-2 text-sm px-3 py-1 rounded-full bg-primary/10 text-primary">
                        {selectedPost.category}
                      </span>
                    )}
                  </div>
                  <LikeButton postId={selectedPost.id} />
                </div>
                {selectedPost.description && (
                  <p className="text-muted-foreground mt-3">{selectedPost.description}</p>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
