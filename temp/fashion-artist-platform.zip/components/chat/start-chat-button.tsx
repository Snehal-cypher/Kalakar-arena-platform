"use client";

import { useState } from "react";
import { MessageCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

interface StartChatButtonProps {
  creatorId: string;
  creatorName: string;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "lg";
  className?: string;
}

export function StartChatButton({
  creatorId,
  creatorName,
  variant = "default",
  size = "default",
  className,
}: StartChatButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const handleStartChat = async () => {
    setIsLoading(true);

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push(`/auth/login?redirect=/creator/${creatorId}`);
        return;
      }

      // Check if conversation already exists
      const { data: existingConv } = await supabase
        .from("conversations")
        .select("id")
        .or(
          `and(participant_1.eq.${user.id},participant_2.eq.${creatorId}),and(participant_1.eq.${creatorId},participant_2.eq.${user.id})`
        )
        .single();

      if (existingConv) {
        // Conversation exists, redirect to messages
        router.push(`/messages?conversation=${existingConv.id}`);
        return;
      }

      // Create new conversation
      const { data: newConv, error } = await supabase
        .from("conversations")
        .insert({
          participant_1: user.id,
          participant_2: creatorId,
        })
        .select("id")
        .single();

      if (error) throw error;

      // Redirect to messages with new conversation
      router.push(`/messages?conversation=${newConv.id}`);
    } catch (error) {
      console.error("Error starting chat:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      onClick={handleStartChat}
      disabled={isLoading}
      variant={variant}
      size={size}
      className={className}
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin mr-2" />
      ) : (
        <MessageCircle className="h-4 w-4 mr-2" />
      )}
      Chat with {creatorName?.split(" ")[0] || "Creator"}
    </Button>
  );
}
