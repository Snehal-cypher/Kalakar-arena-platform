"use client";

import { useState } from "react";
import type { User } from "@supabase/supabase-js";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProfileSetup } from "./profile-setup";
import { PostsManager } from "./posts-manager";
import { ContactRequests } from "./contact-requests";
import { Users, ImageIcon, MessageSquare, LayoutDashboard } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface CreatorProfile {
  id: string;
  bio: string | null;
  avatar_url: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  categories: string[] | null;
  portfolio_images: string[] | null;
}

interface Post {
  id: string;
  title: string;
  description: string | null;
  image_url: string;
  category: string | null;
  created_at: string;
}

interface ContactRequest {
  id: string;
  message: string;
  status: string;
  created_at: string;
  profiles: {
    full_name: string;
    avatar_url: string | null;
  };
}

interface DashboardContentProps {
  user: User;
  creatorProfile: CreatorProfile | null;
  posts: Post[];
  followerCount: number;
  contactRequests: ContactRequest[];
}

export function DashboardContent({
  user,
  creatorProfile,
  posts,
  followerCount,
  contactRequests,
}: DashboardContentProps) {
  const [activeTab, setActiveTab] = useState(creatorProfile ? "overview" : "profile");

  const stats = [
    {
      label: "Followers",
      value: followerCount,
      icon: Users,
    },
    {
      label: "Posts",
      value: posts.length,
      icon: ImageIcon,
    },
    {
      label: "Inquiries",
      value: contactRequests.length,
      icon: MessageSquare,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-bold text-foreground">
          Welcome, {user.user_metadata?.full_name || "Creator"}
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage your portfolio, posts, and connect with customers
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {stats.map((stat) => (
          <Card key={stat.label} className="border-border">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <stat.icon className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted">
          <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <LayoutDashboard className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="profile" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Users className="w-4 h-4 mr-2" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="posts" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <ImageIcon className="w-4 h-4 mr-2" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="requests" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <MessageSquare className="w-4 h-4 mr-2" />
            Requests
            {contactRequests.filter(r => r.status === "pending").length > 0 && (
              <span className="ml-2 bg-destructive text-destructive-foreground text-xs rounded-full px-2 py-0.5">
                {contactRequests.filter(r => r.status === "pending").length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Recent Posts */}
            <Card className="border-border">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-semibold mb-4">Recent Posts</h3>
                {posts.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No posts yet. Start showcasing your work!</p>
                ) : (
                  <div className="space-y-3">
                    {posts.slice(0, 3).map((post) => (
                      <div key={post.id} className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-muted overflow-hidden">
                          {post.image_url && (
                            <img src={post.image_url || "/placeholder.svg"} alt={post.title} className="w-full h-full object-cover" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-foreground truncate">{post.title}</div>
                          <div className="text-xs text-muted-foreground">{post.category}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Requests */}
            <Card className="border-border">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-semibold mb-4">Recent Inquiries</h3>
                {contactRequests.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No inquiries yet. Keep sharing your work!</p>
                ) : (
                  <div className="space-y-3">
                    {contactRequests.slice(0, 3).map((request) => (
                      <div key={request.id} className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="text-primary font-medium">
                            {request.profiles?.full_name?.charAt(0) || "U"}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-foreground truncate">
                            {request.profiles?.full_name || "User"}
                          </div>
                          <div className="text-xs text-muted-foreground truncate">{request.message}</div>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          request.status === "pending" 
                            ? "bg-yellow-100 text-yellow-700"
                            : request.status === "accepted"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}>
                          {request.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="profile">
          <ProfileSetup user={user} creatorProfile={creatorProfile} />
        </TabsContent>

        <TabsContent value="posts">
          <PostsManager userId={user.id} posts={posts} />
        </TabsContent>

        <TabsContent value="requests">
          <ContactRequests requests={contactRequests} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
