"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, X, Loader2, MessageSquare, Clock, CheckCircle, XCircle } from "lucide-react";

interface ContactRequest {
  id: string;
  message: string;
  status: string;
  created_at: string;
  profiles: {
    full_name: string;
    avatar_url: string | null;
  };
}

interface ContactRequestsProps {
  requests: ContactRequest[];
}

export function ContactRequests({ requests }: ContactRequestsProps) {
  const [updating, setUpdating] = useState<string | null>(null);
  const router = useRouter();
  const supabase = createClient();

  const handleUpdateStatus = async (requestId: string, status: "accepted" | "rejected") => {
    setUpdating(requestId);
    
    const { error } = await supabase
      .from("contact_requests")
      .update({ status })
      .eq("id", requestId);
    
    setUpdating(null);

    if (error) {
      console.error("Error updating request:", error);
      return;
    }

    router.refresh();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case "accepted":
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "rejected":
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "accepted":
        return "bg-green-100 text-green-700";
      case "rejected":
        return "bg-red-100 text-red-700";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  if (requests.length === 0) {
    return (
      <Card className="border-border border-dashed">
        <CardContent className="py-12 text-center">
          <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h4 className="font-medium text-foreground mb-2">No contact requests yet</h4>
          <p className="text-sm text-muted-foreground">
            When customers are interested in your work, their inquiries will appear here
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-serif text-xl font-semibold text-foreground">Contact Requests</h3>
        <p className="text-sm text-muted-foreground">Manage inquiries from interested customers</p>
      </div>

      <div className="space-y-3">
        {requests.map((request) => (
          <Card key={request.id} className="border-border">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-primary font-semibold text-lg">
                    {request.profiles?.full_name?.charAt(0) || "U"}
                  </span>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-foreground">
                      {request.profiles?.full_name || "Unknown User"}
                    </span>
                    <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${getStatusStyles(request.status)}`}>
                      {getStatusIcon(request.status)}
                      {request.status}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">
                    {formatDate(request.created_at)}
                  </p>
                  <p className="text-foreground bg-muted rounded-lg p-3 text-sm">
                    {request.message}
                  </p>
                </div>

                {request.status === "pending" && (
                  <div className="flex gap-2 flex-shrink-0">
                    <Button
                      size="sm"
                      onClick={() => handleUpdateStatus(request.id, "accepted")}
                      disabled={updating === request.id}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      {updating === request.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Check className="w-4 h-4" />
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateStatus(request.id, "rejected")}
                      disabled={updating === request.id}
                      className="border-destructive text-destructive hover:bg-destructive/10"
                    >
                      {updating === request.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <X className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
