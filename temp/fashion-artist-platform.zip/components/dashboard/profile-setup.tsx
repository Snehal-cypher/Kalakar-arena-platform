"use client";

import React from "react"

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { User } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Save, CheckCircle } from "lucide-react";

const CATEGORIES = [
  "Fashion Design",
  "Home Baking",
  "Jewelry Making",
  "Embroidery",
  "Candle Making",
  "Pottery",
  "Crochet & Knitting",
  "Mehendi Art",
  "Custom Cakes",
  "Handmade Crafts",
  "Photography",
  "Painting",
  "Calligraphy",
];

interface CreatorProfile {
  id: string;
  bio: string | null;
  avatar_url: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  categories: string[] | null;
  portfolio_images: string[] | null;
}

interface ProfileSetupProps {
  user: User;
  creatorProfile: CreatorProfile | null;
}

export function ProfileSetup({ user, creatorProfile }: ProfileSetupProps) {
  const [bio, setBio] = useState(creatorProfile?.bio || "");
  const [phone, setPhone] = useState(creatorProfile?.phone || "");
  const [address, setAddress] = useState(creatorProfile?.address || "");
  const [city, setCity] = useState(creatorProfile?.city || "");
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    creatorProfile?.categories || []
  );
  const [avatarUrl, setAvatarUrl] = useState(creatorProfile?.avatar_url || "");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    const profileData = {
      id: user.id,
      bio,
      phone,
      address,
      city,
      categories: selectedCategories,
      avatar_url: avatarUrl || null,
    };

    const { error } = await supabase
      .from("creator_profiles")
      .upsert(profileData);

    setLoading(false);

    if (error) {
      console.error("Error saving profile:", error);
      return;
    }

    setSuccess(true);
    router.refresh();
    setTimeout(() => setSuccess(false), 3000);
  };

  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle className="font-serif">Your Creator Profile</CardTitle>
        <CardDescription>
          Set up your profile to help customers find and learn about you
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Avatar URL */}
          <div className="space-y-2">
            <Label htmlFor="avatarUrl">Profile Picture URL</Label>
            <Input
              id="avatarUrl"
              type="url"
              placeholder="https://example.com/your-photo.jpg"
              value={avatarUrl}
              onChange={(e) => setAvatarUrl(e.target.value)}
              className="border-input"
            />
            {avatarUrl && (
              <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-primary">
                <img src={avatarUrl || "/placeholder.svg"} alt="Profile preview" className="w-full h-full object-cover" />
              </div>
            )}
          </div>

          {/* Bio */}
          <div className="space-y-2">
            <Label htmlFor="bio">About You & Your Work</Label>
            <Textarea
              id="bio"
              placeholder="Tell customers about your craft, experience, and what makes your work special..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={4}
              className="border-input resize-none"
            />
          </div>

          {/* Categories */}
          <div className="space-y-2">
            <Label>Your Specialties (Select all that apply)</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {CATEGORIES.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => toggleCategory(category)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                    selectedCategories.includes(category)
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-primary/10"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+91 9876543210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="border-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                type="text"
                placeholder="Mumbai"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="border-input"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Full Address (Optional)</Label>
            <Textarea
              id="address"
              placeholder="Your studio/workshop address..."
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={2}
              className="border-input resize-none"
            />
          </div>

          <div className="flex items-center gap-4">
            <Button
              type="submit"
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Profile
                </>
              )}
            </Button>
            {success && (
              <span className="flex items-center text-green-600 text-sm">
                <CheckCircle className="w-4 h-4 mr-1" />
                Profile saved!
              </span>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
