import { Palette, ShoppingBag, MessageCircle, Star } from "lucide-react";

const features = [
  {
    icon: Palette,
    title: "Showcase Your Art",
    description: "Create a stunning portfolio to display your unique creations, from fashion designs to handcrafted jewelry and baked delights."
  },
  {
    icon: ShoppingBag,
    title: "Discover Local Talent",
    description: "Find amazing local artists and creators who can bring your custom ideas to life with their exceptional skills."
  },
  {
    icon: MessageCircle,
    title: "Direct Connection",
    description: "Connect directly with creators, discuss your requirements, and get personalized creations tailored just for you."
  },
  {
    icon: Star,
    title: "Support Small Businesses",
    description: "Help local artisans and newly graduated designers grow their business while getting unique, quality products."
  }
];

export function AboutSection() {
  return (
    <section className="py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground text-balance">
            What is <span className="text-primary">KALAKAR ARENA</span>?
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            A platform designed to bridge the gap between talented local creators 
            and people seeking unique, handcrafted products and services.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-card rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow border border-border"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <feature.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Categories Preview */}
        <div className="mt-20">
          <h3 className="font-serif text-2xl font-bold text-foreground text-center mb-8">
            Explore Creative Categories
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {[
              "Fashion Design",
              "Home Baking",
              "Jewelry Making",
              "Embroidery",
              "Candle Making",
              "Pottery",
              "Crochet & Knitting",
              "Mehendi Art",
              "Custom Cakes",
              "Handmade Crafts"
            ].map((category) => (
              <span
                key={category}
                className="px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition-colors cursor-pointer"
              >
                {category}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
