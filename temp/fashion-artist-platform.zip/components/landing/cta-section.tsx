import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export function CTASection() {
  return (
    <section className="py-24 bg-primary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-white rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-primary-foreground text-balance">
          Ready to Start Your Creative Journey?
        </h2>
        <p className="mt-6 text-lg text-primary-foreground/80 max-w-2xl mx-auto text-pretty">
          Whether you are a talented creator looking to showcase your work or someone 
          seeking unique handcrafted items, KALAKAR ARENA is the perfect platform for you.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/auth/sign-up?type=creator">
            <Button size="lg" className="bg-background text-primary hover:bg-background/90 px-8 py-6 text-lg">
              Start as Creator
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <Link href="/explore">
            <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 px-8 py-6 text-lg bg-transparent">
              Explore Creators
            </Button>
          </Link>
        </div>

        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-primary-foreground/80">
          <div>
            <div className="text-2xl font-bold text-primary-foreground">Free</div>
            <div className="text-sm">To Join</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-primary-foreground">Direct</div>
            <div className="text-sm">Contact</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-primary-foreground">Local</div>
            <div className="text-sm">Artisans</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-primary-foreground">Custom</div>
            <div className="text-sm">Creations</div>
          </div>
        </div>
      </div>
    </section>
  );
}
