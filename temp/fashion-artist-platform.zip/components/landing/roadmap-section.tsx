"use client";

import { Search, UserPlus, MessageSquare, Package, Star } from "lucide-react";

const steps = [
  {
    icon: UserPlus,
    title: "Create Your Account",
    description: "Sign up as a User to explore, or as a Creator to showcase your talent. It's free and takes just a minute.",
    color: "bg-primary"
  },
  {
    icon: Search,
    title: "Discover or Setup",
    description: "Users can search for creators by category like baking, jewelry, or embroidery. Creators can build their portfolio with images and descriptions.",
    color: "bg-accent"
  },
  {
    icon: MessageSquare,
    title: "Connect & Discuss",
    description: "Found someone interesting? Send a contact request to discuss your requirements, pricing, and timeline directly with the creator.",
    color: "bg-primary"
  },
  {
    icon: Package,
    title: "Get Custom Creations",
    description: "Work together to bring your vision to life. Get unique, handcrafted items made specifically for you by talented local artisans.",
    color: "bg-accent"
  },
  {
    icon: Star,
    title: "Follow & Support",
    description: "Love a creator's work? Follow them to stay updated on their latest creations and support local talent in your community.",
    color: "bg-primary"
  }
];

export function RoadmapSection() {
  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute left-1/2 top-0 bottom-0 w-px bg-border hidden lg:block" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground text-balance">
            Your Journey to <span className="text-primary">Unique Creations</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Follow this simple roadmap to find the perfect creator for your needs 
            or start showcasing your artistic talent to the world.
          </p>
        </div>

        <div className="relative">
          {/* Mobile/Tablet View */}
          <div className="lg:hidden space-y-8">
            {steps.map((step, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className={`w-12 h-12 rounded-full ${step.color} flex items-center justify-center flex-shrink-0`}>
                    <step.icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                  {index < steps.length - 1 && (
                    <div className="w-px h-full bg-border mt-2" />
                  )}
                </div>
                <div className="pb-8">
                  <div className="text-sm font-medium text-primary mb-1">Step {index + 1}</div>
                  <h3 className="font-serif text-xl font-semibold text-foreground mb-2">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Desktop View - Alternating */}
          <div className="hidden lg:block space-y-16">
            {steps.map((step, index) => (
              <div 
                key={index} 
                className={`flex items-center gap-8 ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}
              >
                <div className={`flex-1 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                  <div className={`text-sm font-medium text-primary mb-2 ${index % 2 === 0 ? 'text-right' : 'text-left'}`}>
                    Step {index + 1}
                  </div>
                  <h3 className="font-serif text-2xl font-semibold text-foreground mb-3">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed max-w-md ml-auto">
                    {step.description}
                  </p>
                </div>
                
                <div className="relative z-10">
                  <div className={`w-16 h-16 rounded-full ${step.color} flex items-center justify-center shadow-lg`}>
                    <step.icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                </div>
                
                <div className="flex-1" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
