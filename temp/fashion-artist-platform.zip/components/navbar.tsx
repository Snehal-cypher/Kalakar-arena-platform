"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Palette, MessageCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { User } from "@supabase/supabase-js";

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [userType, setUserType] = useState<string | null>(null);
  const supabase = createClient();

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      if (user) {
        setUserType(user.user_metadata?.user_type || null);
      }
    };
    getUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        setUserType(session.user.user_metadata?.user_type || null);
      }
    });

    return () => subscription.unsubscribe();
  }, [supabase.auth]);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-background">
              <Palette className="text-accent w-[100px] h-[100px]" />
            </div>
            <span className="font-serif text-xl font-bold text-foreground">KALAKAR ARENA</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/explore" className="text-muted-foreground hover:text-primary transition-colors">
              Explore
            </Link>
            <Link href="/categories" className="text-muted-foreground hover:text-primary transition-colors">
              Categories
            </Link>
            <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
              About
            </Link>
            {user ? (
              <div className="flex items-center gap-4">
                <Link href="/messages" className="text-muted-foreground hover:text-primary transition-colors relative">
                  <MessageCircle className="w-5 h-5" />
                </Link>
                <Link href={userType === 'creator' ? '/dashboard' : '/profile'}>
                  <Button variant="default" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    {userType === 'creator' ? 'Dashboard' : 'Profile'}
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Link href="/auth/login">
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary/10 bg-transparent">
                    Sign In
                  </Button>
                </Link>
                <Link href="/auth/sign-up">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Get Started
                  </Button>
                </Link>
              </div>
            )}
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-4">
              <Link href="/explore" className="text-muted-foreground hover:text-primary transition-colors">
                Explore
              </Link>
              <Link href="/categories" className="text-muted-foreground hover:text-primary transition-colors">
                Categories
              </Link>
              <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                About
              </Link>
              {user ? (
                <>
                  <Link href="/messages" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
                    <MessageCircle className="w-5 h-5" />
                    Messages
                  </Link>
                  <Link href={userType === 'creator' ? '/dashboard' : '/profile'}>
                    <Button variant="default" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                      {userType === 'creator' ? 'Dashboard' : 'Profile'}
                    </Button>
                  </Link>
                </>
              ) : (
                <div className="flex flex-col gap-2">
                  <Link href="/auth/login">
                    <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/10 bg-transparent">
                      Sign In
                    </Button>
                  </Link>
                  <Link href="/auth/sign-up">
                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                      Get Started
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
