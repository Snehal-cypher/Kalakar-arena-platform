"use client";

import { useState } from "react";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LikeButton } from "./like-button";
import { formatDistanceToNow } from "date-fns";

interface PostCardProps {
  post: {
    id: string;
    title: string;
    description?: string | null;
    image_url: string;
    category?: string | null;
    created_at: string;
  };
  creatorName?: string;
  showCreator?: boolean;
}

export function PostCard({ post, creatorName, showCreator = false }: PostCardProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <Card className="overflow-hidden group hover:shadow-lg transition-shadow border-border/50">
      <div className="relative aspect-square overflow-hidden bg-muted">
        {!imageError ? (
          <Image
            src={post.image_url || "/placeholder.svg"}
            alt={post.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/5">
            <span className="text-muted-foreground text-sm">No image</span>
          </div>
        )}
        
        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        
        {/* Like button overlay */}
        <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <LikeButton postId={post.id} size="sm" />
        </div>
      </div>

      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-foreground truncate">{post.title}</h3>
            {showCreator && creatorName && (
              <p className="text-sm text-muted-foreground truncate">by {creatorName}</p>
            )}
          </div>
          <LikeButton postId={post.id} size="sm" />
        </div>

        {post.description && (
          <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
            {post.description}
          </p>
        )}

        <div className="flex items-center justify-between mt-3">
          {post.category && (
            <Badge variant="secondary" className="text-xs">
              {post.category}
            </Badge>
          )}
          <span className="text-xs text-muted-foreground">
            {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
