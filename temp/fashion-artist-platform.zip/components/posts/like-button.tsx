"use client";

import { useState, useEffect } from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

interface LikeButtonProps {
  postId: string;
  initialLikesCount?: number;
  showCount?: boolean;
  size?: "sm" | "default";
}

export function LikeButton({
  postId,
  initialLikesCount = 0,
  showCount = true,
  size = "default",
}: LikeButtonProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(initialLikesCount);
  const [isLoading, setIsLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const supabase = createClient();

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
        // Check if user has liked this post
        const { data } = await supabase
          .from("likes")
          .select("id")
          .eq("post_id", postId)
          .eq("user_id", user.id)
          .single();

        setIsLiked(!!data);
      }
    };

    const fetchLikesCount = async () => {
      const { count } = await supabase
        .from("likes")
        .select("*", { count: "exact", head: true })
        .eq("post_id", postId);

      setLikesCount(count || 0);
    };

    checkUser();
    fetchLikesCount();
  }, [postId, supabase]);

  const handleLike = async () => {
    if (!userId) {
      // Redirect to login if not authenticated
      window.location.href = "/auth/login?redirect=/explore";
      return;
    }

    setIsLoading(true);

    try {
      if (isLiked) {
        // Unlike
        await supabase
          .from("likes")
          .delete()
          .eq("post_id", postId)
          .eq("user_id", userId);

        setIsLiked(false);
        setLikesCount((prev) => Math.max(0, prev - 1));
      } else {
        // Like
        await supabase.from("likes").insert({
          post_id: postId,
          user_id: userId,
        });

        setIsLiked(true);
        setLikesCount((prev) => prev + 1);
      }
    } catch (error) {
      console.error("Error toggling like:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      variant="ghost"
      size={size === "sm" ? "sm" : "default"}
      onClick={handleLike}
      disabled={isLoading}
      className={cn(
        "gap-1.5 transition-colors",
        isLiked && "text-red-500 hover:text-red-600"
      )}
    >
      <Heart
        className={cn(
          size === "sm" ? "h-4 w-4" : "h-5 w-5",
          isLiked && "fill-current"
        )}
      />
      {showCount && <span className="text-sm">{likesCount}</span>}
    </Button>
  );
}
