"use client";

import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { MessageCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { createClient } from "@/lib/supabase/client";
import { ChatWindow } from "@/components/chat/chat-window";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

interface Conversation {
  id: string;
  participant_1: string;
  participant_2: string;
  last_message_at: string;
  created_at: string;
  otherUser?: {
    id: string;
    full_name: string | null;
    avatar_url: string | null;
  };
  unreadCount?: number;
  lastMessage?: string;
}

interface MessagesContentProps {
  currentUserId: string;
  userType: string;
}

export function MessagesContent({
  currentUserId,
  userType,
}: MessagesContentProps) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedConversation, setSelectedConversation] =
    useState<Conversation | null>(null);
  const searchParams = useSearchParams();
  const conversationParam = searchParams.get("conversation");
  const supabase = createClient();

  useEffect(() => {
    const fetchConversations = async () => {
      setIsLoading(true);

      // Fetch conversations where current user is a participant
      const { data: convs } = await supabase
        .from("conversations")
        .select("*")
        .or(
          `participant_1.eq.${currentUserId},participant_2.eq.${currentUserId}`
        )
        .order("last_message_at", { ascending: false });

      if (!convs) {
        setIsLoading(false);
        return;
      }

      // Fetch other users' details
      const otherUserIds = convs.map((c) =>
        c.participant_1 === currentUserId ? c.participant_2 : c.participant_1
      );

      const { data: users } = await supabase
        .from("profiles")
        .select("id, full_name, avatar_url")
        .in("id", otherUserIds);

      // Fetch unread counts and last messages
      const conversationsWithDetails = await Promise.all(
        convs.map(async (conv) => {
          const otherUserId =
            conv.participant_1 === currentUserId
              ? conv.participant_2
              : conv.participant_1;

          const otherUser = users?.find((u) => u.id === otherUserId);

          // Get unread count
          const { count } = await supabase
            .from("messages")
            .select("*", { count: "exact", head: true })
            .eq("conversation_id", conv.id)
            .eq("is_read", false)
            .neq("sender_id", currentUserId);

          // Get last message
          const { data: lastMsg } = await supabase
            .from("messages")
            .select("content")
            .eq("conversation_id", conv.id)
            .order("created_at", { ascending: false })
            .limit(1)
            .single();

          return {
            ...conv,
            otherUser: otherUser || {
              id: otherUserId,
              full_name: null,
              avatar_url: null,
            },
            unreadCount: count || 0,
            lastMessage: lastMsg?.content,
          };
        })
      );

      setConversations(conversationsWithDetails);

      // Auto-select conversation from URL param
      if (conversationParam) {
        const conv = conversationsWithDetails.find(
          (c) => c.id === conversationParam
        );
        if (conv) {
          setSelectedConversation(conv);
        }
      }

      setIsLoading(false);
    };

    fetchConversations();

    // Subscribe to conversation updates
    const channel = supabase
      .channel("messages-page-updates")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "messages",
        },
        () => {
          fetchConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUserId, conversationParam, supabase]);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Conversations List */}
      <Card className="lg:col-span-1">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <MessageCircle className="h-5 w-5 text-primary" />
            Conversations
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {conversations.length === 0 ? (
            <div className="text-center py-8 px-4 text-muted-foreground">
              <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="font-medium">No conversations yet</p>
              <p className="text-sm mt-1">
                {userType === "creator"
                  ? "Users will message you when they want to connect"
                  : "Start chatting with a creator to see messages here"}
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[500px]">
              <div className="px-2 pb-2">
                {conversations.map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv)}
                    className={cn(
                      "w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left mb-1",
                      selectedConversation?.id === conv.id
                        ? "bg-primary/10 border border-primary/20"
                        : "hover:bg-muted"
                    )}
                  >
                    <Avatar className="h-11 w-11">
                      <AvatarImage
                        src={conv.otherUser?.avatar_url || undefined}
                      />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {conv.otherUser?.full_name?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium truncate text-sm">
                          {conv.otherUser?.full_name || "User"}
                        </h4>
                        {conv.unreadCount && conv.unreadCount > 0 ? (
                          <Badge className="bg-primary text-primary-foreground text-xs h-5 min-w-5 flex items-center justify-center">
                            {conv.unreadCount}
                          </Badge>
                        ) : null}
                      </div>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">
                        {conv.lastMessage || "No messages yet"}
                      </p>
                      <p className="text-xs text-muted-foreground/70 mt-1">
                        {formatDistanceToNow(new Date(conv.last_message_at), {
                          addSuffix: true,
                        })}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Chat Window */}
      <div className="lg:col-span-2">
        {selectedConversation && selectedConversation.otherUser ? (
          <ChatWindow
            conversationId={selectedConversation.id}
            currentUserId={currentUserId}
            otherUser={selectedConversation.otherUser}
            onClose={() => setSelectedConversation(null)}
          />
        ) : (
          <Card className="h-[500px] flex items-center justify-center">
            <div className="text-center text-muted-foreground px-4">
              <MessageCircle className="h-16 w-16 mx-auto mb-4 opacity-30" />
              <p className="font-medium">Select a conversation</p>
              <p className="text-sm mt-1">
                Choose a conversation from the list to start chatting
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
